import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'kt-ngbootstrap',
	templateUrl: './ngbootstrap.component.html',
})
export class NgbootstrapComponent implements OnInit {

	constructor() {
	}

	ngOnInit() {
	}
}
