export class CCTimeMgtDetailRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public RoleID: Number;    
    public aux_code: string;
    public GroupBy:string;
}
