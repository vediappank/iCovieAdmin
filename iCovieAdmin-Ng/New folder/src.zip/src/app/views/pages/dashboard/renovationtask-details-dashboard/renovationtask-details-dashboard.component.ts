import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-renovationtask-details-dashboard',
  templateUrl: './renovationtask-details-dashboard.component.html',
  styleUrls: ['./renovationtask-details-dashboard.component.scss']
})
export class RenovationtaskDetailsDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
