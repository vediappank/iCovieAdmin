export class CCAbsentiesRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public dayorweek: string; 
    public RoleID: Number;      
    public GroupBy: string;      
}
