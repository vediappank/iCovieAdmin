export class CCOutBoundRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public RoleID: Number;    
    public GroupBy: string;    
}
