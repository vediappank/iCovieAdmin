export class CCFinanceRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public GroupBy: string; 
    public dayorweek: string; 
    public RoleID: Number;    
}