export class ActivityWidgetRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public RoleID: Number;          
    public ActivityID: string;          
}
