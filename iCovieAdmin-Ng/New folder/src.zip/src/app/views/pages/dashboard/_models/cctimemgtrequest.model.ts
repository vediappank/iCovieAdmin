export class CCTimeMgtRequest {
    AuxCode:string;
    TotalDuration:string;
    AuxPer:string;
   AvgDuration:string;   
}
