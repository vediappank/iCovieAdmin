export class    InputRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public RoleID: Number;  
    public dayorweek: string;      
    public medialist: any[];      
}
