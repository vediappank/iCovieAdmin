import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-delay-task-dashboard',
  templateUrl: './delay-task-dashboard.component.html',
  styleUrls: ['./delay-task-dashboard.component.scss']
})
export class DelayTaskDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
