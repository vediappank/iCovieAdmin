export class DashLocationRequest {
    
    public repStartDate: string;  
    public  repEndDate:string;
    public locationid:string;  
    public companyid:string;
    // public ratio_Row_RoleID: Number;    
    // public type: string;    
    // public orderby: string;    
}
