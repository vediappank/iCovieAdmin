export class CCInboundRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public GroupBy: string; 
    public RoleID: Number;    
}
