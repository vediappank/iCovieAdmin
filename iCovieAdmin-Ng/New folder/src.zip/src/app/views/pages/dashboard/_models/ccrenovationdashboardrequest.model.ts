export class CCRenovationDashboardRequest {
     public repStartDate: string;
     public repEndDate: string; 
     public locationid: Number;
     public companyid: Number;    
 }
 