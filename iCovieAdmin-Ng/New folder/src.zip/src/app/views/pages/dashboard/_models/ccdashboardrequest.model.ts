export class CCDashboardRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public RoleID: Number;    
    // public ratio_Row_RoleID: Number;    
    // public type: string;    
    // public orderby: string;    
}
