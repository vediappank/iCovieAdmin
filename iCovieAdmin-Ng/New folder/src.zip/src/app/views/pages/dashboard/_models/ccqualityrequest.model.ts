export class CCQualityRequest {
    public callcenter: string;
    public repStartDate: string;
    public repEndDate: string; 
    public GroupBy: string; 
    public RoleID: Number; 
    public dayorweek: string;      
    public medialist: any[];  
}
