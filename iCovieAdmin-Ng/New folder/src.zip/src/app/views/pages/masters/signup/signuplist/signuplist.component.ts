import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-signuplist',
  templateUrl: './signuplist.component.html',
  styleUrls: ['./signuplist.component.scss']
})
export class SignuplistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
