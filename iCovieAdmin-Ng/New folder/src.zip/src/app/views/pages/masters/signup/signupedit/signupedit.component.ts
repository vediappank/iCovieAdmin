import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-signupedit',
  templateUrl: './signupedit.component.html',
  styleUrls: ['./signupedit.component.scss']
})
export class SignupeditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
