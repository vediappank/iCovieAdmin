export class PropertyAminitiesModel {
    aminitiesid: number;   
    aminitiestypeid: number;
   
    
}

