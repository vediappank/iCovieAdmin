export class RolePermissionMapping {
    Read: string;
  Task: string;
  Delete: boolean;
  Modifiy: boolean;
}
