import { UpdatePropertyImagesModel } from '../..';

export class UpdatePropertyImagesRequestModel {    
    file:FormData;
    uploadFiles:UpdatePropertyImagesModel[];
}

