export class MCityImagesModel {
    //id: number;
    cityid: number;
    imagename: string;
    imagepath: string;
    showimagepath: string;
   // files:FormData;
    //cid: number;
    

}

