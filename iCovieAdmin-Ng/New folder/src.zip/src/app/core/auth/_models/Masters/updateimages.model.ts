export class UpdatePropertyImagesModel {    
    propertyid: number;
    imagename: string;
    imagepath: string;
    showimagepath: string;
    
}

