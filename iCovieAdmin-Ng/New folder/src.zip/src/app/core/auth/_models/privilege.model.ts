export class privilege
{
      menu_id:number;      
      menu_name:string;
      privilege_id:number;
      privilegename:string;
      privilege_description:string;
}