export class PropertyNeighbourTypeModel {
    PropertyNeighbourCategoryid: number;   
    PropertyNeighbourTypeid: number;
   
}