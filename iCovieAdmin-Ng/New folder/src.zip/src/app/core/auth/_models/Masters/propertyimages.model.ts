export class PropertyImagesModel {
    //id: number;
    propertyid: number;
    imagename: string;
    imagepath: string;
    showimagepath: string;
   // files:FormData;
    //cid: number;
    

}

